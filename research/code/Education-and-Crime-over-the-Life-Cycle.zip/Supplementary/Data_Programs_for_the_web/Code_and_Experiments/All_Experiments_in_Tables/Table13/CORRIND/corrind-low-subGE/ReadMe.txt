Lower Correlation of productive ability and crime fixed effects (GE)

Goal: General equilibrium for lower rho

Folder: corrind-low-subGE

File change:  fixed_params.txt

Code change : No change 
