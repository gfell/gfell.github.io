Higher Correlation of productive ability and crime fixed effects (benchmark)

Goal: benchmark model for higher rho

Folder: corrind-high

File change:  fixed_params.txt

Code change : No change 
