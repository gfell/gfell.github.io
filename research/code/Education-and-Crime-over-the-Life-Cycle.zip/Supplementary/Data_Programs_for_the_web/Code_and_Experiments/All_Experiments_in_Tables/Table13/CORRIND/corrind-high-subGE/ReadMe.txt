Higher Correlation of productive ability and crime fixed effects (GE)

Goal: General equilibrium for higher rho

Folder: corrind-high-subGE

File change:  fixed_params.txt

Code change : No change 
