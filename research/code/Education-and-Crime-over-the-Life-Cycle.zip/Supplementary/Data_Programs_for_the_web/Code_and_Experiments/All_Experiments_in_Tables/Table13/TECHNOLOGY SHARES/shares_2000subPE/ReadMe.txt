Labour share in year 2000 (PE)

Goal: Partial equilibrium for changing labour share in year 2000

Folder: shares_2000subPE

File change:  fixed_params.txt

Code change : No change 
