Lower Correlation of productive ability and crime fixed effects (benchmark)

Goal: benchmark model for lower rho

Folder: corrind-low

File change:  fixed_params.txt

Code change : No change 
