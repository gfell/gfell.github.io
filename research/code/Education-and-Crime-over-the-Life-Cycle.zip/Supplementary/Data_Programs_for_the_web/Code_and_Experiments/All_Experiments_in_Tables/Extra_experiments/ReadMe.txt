Experiments not included in the paper. Looser borrowing limit (benchmark and GE high school subsidy equal to 8.8% of uncavgearn)

Folders: 
- rho_bench_bc5x (benchmark)
- rho_bench_bc5x_GE (GE experiment) 

File change: 
- fixed_params.txt
-in_condition.txt
  wmin = -4.9


Code change : No change 
