Looser borrowing limit (GE)

Goal: General equilibrium for making borrowing limit (wmin) become looser

Folder: robwmin4.9-subGE

File change: 
- fixed_params.txt
-in_condition.txt
  wmin = -4.9


Code change : No change 
