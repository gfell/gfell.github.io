This folder contains the Markov chains for two alternative income definitions:

- Male *pre-tax* earnings, defined as "Head of household total labor income" in the PSID. 

- Household *pre-tax* earnings, defined as the sum of the labor income of the head of household and the labor income of the spouse.

For both, the sample is identical to that used to estimate the process
for *disposable* household earnings used in the paper. The only
exception is that the lower limit on earnings ($1500) is imposed in
male earnings and household earnings respectively, rather than in
household post-tax nonfinancial income.
