This folder contains the estimated coefficients, state spaces and transition
 matrices associated with the nonlinear (NL) process in De Nardi, Fella, and
 Paz-Pardo (2018), NBER working paper 24326, forthcoming in the Journal of the
 European Economic Association. 




In the paper, we first estimate a flexible, non-linear process from PSID 
household-level, post-tax earnings data. This process features a persistent and 
a transitory component, that we estimate following Arellano, Blundell and
 Bonhomme (Econometrica 2017), as we describe in Section 3 of the paper. We then
 use the estimated earnings process to simulate a large sample of histories for 
both the transitory and the persistent earnings components. We use the simulated 
data to compute Markov chains for each component that we also include in this
 file. The details of their computation and discretization are in Section 4 of
 the paper. Additional information about the transitory component and its 
discretization is available in Appendix D.2.



The relevant files and code are described below



1. "ABB_coefficients.xlsx" contains the coefficients associated with the
 nonlinear earnings process we estimate on the data. Namely, it contains the
 "a" coefficients that we define in equations (6), (7), (8) in Section 3.2.,
 together with the tail coefficients lambda that we define in the same
 section. They are estimated for 11 quantiles which are equally spaced (from
 1/12=0.0833 to 11/12=0.9167), following Arellano, Blundell and Bonhomme
 (2017).



2.  "dfp.matrices.R" contains the R code used to generate state spaces and
 transition matrices from a panel of data, with the possibility of choosing
 the intervals for the discretization.



3. "eta_space_N.csv" contains the grid of points, at each age, for the Markov
 chain for the persistent earnings component. N denotes the number of grid
 points.



4. "eta_tranmatrices_N.csv" contains the elements of the age-dependent
 transition matrices (from grid-point "q" at age t to grid point "nq" at age
   t+1) for the persistent component. N denotes the number of grid points.
 


5. "eps_space_N.csv" contains the grid of points, at each age, for the Markov
 chain for the transitory earnings component. N denotes the number of grid
 points.



6. "eps_tranmatrices_N.csv" contains the elements of the age-dependent
 transition matrices (from grid-point "q" at age t to grid point "nq" at age
 t+1) for the transitory earnings component. N denotes the number of grid
 points.





- Users interested in directly using the earnings process and discretization
 used in the main body of De Nardi, Fella and Paz-Pardo (2018) to their
 framework can use eta_space_18.csv, eps_space_8.csv, eta_tranmatrices_18.csv
  and eps_tranmatrices_8.csv directly.



- Users interested in the finer discretization in Appendix C.2 of De Nardi,
 Fella and Paz-Pardo (2018) can use the files eta_space_36.csv,
 eta_tranmatrices_36.csv, eps_space_16.csv and eps_tranmatrices_16.csv.



- Users interested in performing their own discretization or simulation with our
  ABB-decomposed PSID sample may simulate histories of realizations using the
  coefficients reported in ABB_coefficients.xlsx.



- Users interested in performing a flexible discretization in the way we propose
 in the paper for either their own earnings data or their own previously
 decomposed (transitory-permanent) earnings data can use the code in
 dfp_matrices.R.