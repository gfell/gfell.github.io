function [f,fparts] = sty_fun(pars,dat,covdat)

ep=pars(1);
n1=pars(2);
v=pars(3);
rho=pars(4);

% First direct part

fparts = rho.^(2*(1:36)'-2)*n1 + ep;
cuca = zeros(36,1);
cuca(1) = n1;
for i=2:36
    for j=2:i
   fparts(i)= fparts(i) + rho.^(2*(i-j))*v;
    end
   cuca(i) = (rho.^2).*cuca(i-1)+v;
end
cuca=cuca+ep;

% Now autocov of order 1

autocov = rho.^(2*(1:35)-1)*n1;

for i=2:35
    for j=2:i
        autocov(i)=autocov(i)+rho^(1+2*(i-j))*v;
    end
end

f1 = norm(autocov-covdat);
f2 = norm(fparts-dat);

f= f1+f2;

f = sum((autocov'-covdat(1:35)).^2)+sum((fparts-dat).^2);

% f1 = dat(1)-fparts(1);
% f2 = dat(10)- fparts(10);
% f3 = dat(20) -fparts(20);
% f4 = dat(30) - fparts(30);
% 
% f=norm([f1 f2 f3 f4]);



end