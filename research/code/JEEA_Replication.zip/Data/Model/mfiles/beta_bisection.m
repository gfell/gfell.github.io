function [bet,topbet,topcriterio,bottombet,bottomcriterio] = ...
    beta_bisection(bet,criterion,criterio,topbet,topcriterio,bottombet,bottomcriterio)

if criterion>0
        topbet=bet;
        topcriterio=criterio; 
        if bottombet==0
            if criterio>0.5
            bet=bet-0.01;
            elseif criterio<0.5 % && criterio>0.1,
            bet=bet-0.003;
            %elseif criterio<0.1,
            %bet=bet-0.0002;
            end   
        elseif bottombet>0
            sumcriterio=criterio+bottomcriterio;
            bet=bottombet*criterio/sumcriterio+bet*...
                bottomcriterio/sumcriterio;
        end
    elseif criterion<0
        bottombet=bet;
        bottomcriterio=criterio;
            if topbet==0
                if criterio>0.5
                bet=bet+0.01;
                elseif criterio<0.5 %  && criterio>0.1,
                    bet=bet+0.003;
                %elseif criterio<0.1,
                %    bet=bet+0.0002;
                end
            elseif topbet>0
                sumcriterio=criterio+topcriterio;
                bet=topbet*criterio/sumcriterio+bet*...
                    topcriterio/sumcriterio;
                
            end
end
    
end
    