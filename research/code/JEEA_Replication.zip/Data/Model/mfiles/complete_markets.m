function [V] = complete_markets(cons,dfact,sig,T,r)

V=0;
for t=1:T
    V=V+dfact(t).*((((1+r).^(t-1)).*cons(t)).^(1-sig))/(1-sig);
end

V=-V;

end